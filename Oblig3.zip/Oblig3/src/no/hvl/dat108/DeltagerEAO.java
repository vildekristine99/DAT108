package no.hvl.dat108;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

//@Stateless
public class DeltagerEAO {
	
	//@PersistenceContext(name = "listePU")
    //private EntityManager em;
	
	public void leggTilDeltager(Deltager deltager) {
		//em.persist(deltager);
	}
}
